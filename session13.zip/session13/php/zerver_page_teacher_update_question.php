<?php
//CHECKED
include 'zerver_entrance.php';

session_start();

error_reporting(0);

$id = $_POST["question_id"];
$hps = $_POST["hps"];
$due = $_POST["due_date"];
$email = $_SESSION["curr_email_user"];
$question = $_POST["question"];
$type = $_POST["type"];
$items = $_POST["items"];
$room = $_POST["room"];
$auto_corr = $_POST["auto_corr"];
$auto_grade = $_POST["auto_grades"];
if($items == "" || $type == "response"){
  $items = "<!@#%GRADES$%^>$auto_grade<!@#CORRECT$%^>$auto_corr<!@#INCORRECT$%^><!@#ENUMERATE$%^>$items";
} else {
  $items = explode(",", $items);
  $hold = "<!@#%GRADES$%^>$auto_grade<!@#CORRECT$%^>$auto_corr<!@#INCORRECT$%^><!@#ENUMERATE$%^>";
  for($i = 0; $i < count($items); $i++){
    $items[$i] = "<*&*>".$items[$i];
    $hold .= $items[$i];
  }
  $items = $hold;
}

$items = str_replace("'", "''", $items);

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  
    $sql = "UPDATE `created_questions` SET `question`='$question',`HPS`='$hps',`due_date`='$due',`checking_param`='$items',`type_question`='$type', classroom_id = '$room' WHERE owner_teacher = '$email' AND question_id = '$id' ";
  
    // Prepare statement
    $stmt = $conn->prepare($sql);
  
    // execute the query
    $stmt->execute();
  
    // echo a message to say the UPDATE succeeded
    echo 'question UPDATED!';
  } catch(PDOException $e) {
    echo $sql . "<br>" . $e->getMessage();
  }
  
  $conn = null;
?>