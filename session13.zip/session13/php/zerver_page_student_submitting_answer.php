<?php

include 'zerver_entrance.php';

session_start();

error_reporting(0);

$email = $_SESSION["curr_email_user"];
$answer = $_POST["answer"];
$qid = $_POST["qid"];

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "INSERT INTO student_answers (answer, question_id, owner_student, time_of_submission, grades, checked, system_confidence, re_eval)
    VALUES ('$answer', '$qid', '$email', current_timestamp(), -1, 0, -1, 0 )";
    // use exec() because no results are returned
    $conn->exec($sql);
    echo "Essay Answer Submitted, please wait for your teacher to evaluate.";
  } catch(PDOException $e) {
    echo $sql . "<br>" . $e->getMessage();
  }
  
  $conn = null;
?>