<?php

include 'zerver_entrance.php';

session_start();

error_reporting(0);

$email = $_SESSION["curr_email_user"];
// $id = $_POST["id"];
$id = 64;

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $stmt = $conn->prepare("SELECT * FROM created_questions WHERE owner_teacher = '$email' AND question_id = '$id'");
  $stmt->execute();

  // set the resulting array to associative
  $result = $stmt->FetchAll(PDO::FETCH_ASSOC);

  $curr = $result[0]["checking_param"];
  $curr_grad = strpos($curr, "<!@#%GRADES$%^>");
  $curr_corr = strpos($curr, "<!@#CORRECT$%^>");
  $curr_inco = strpos($curr, "<!@#INCORRECT$%^>");
  $curr_enum = strpos($curr, "<!@#ENUMERATE$%^>");
  $str_grad = "";
  $str_corr = "";
  $str_inco = "";
  $str_enum = "";

  for ($x = 15; $x < $curr_corr; $x++) {
    $str_grad .= $curr[$x];
  }
  for ($x = $curr_corr + 15; $x < $curr_inco; $x++) {
    $str_corr .= $curr[$x];
  }
  for ($x = $curr_inco + 17; $x < $curr_enum; $x++) {
    $str_inco .= $curr[$x];
  }
  for ($x = $curr_enum + 17; $x < strlen($curr); $x++) {
    $str_enum .= $curr[$x];
  }

  $str_grad = array_merge(array_filter(explode("<&**>", $str_grad)));
  $str_corr = array_merge(array_filter(explode("<&**>", str_replace("<&*>","",$str_corr))));
  $str_enum = array_merge(array_filter(explode("<*&*>", $str_enum)));
  print_r($str_corr);
  
  // print_r($arr_enum); CHECKPOINT

  

} catch(PDOException $e) {
  echo "Error: " . $e->getMessage();
}

$conn = null;
?>