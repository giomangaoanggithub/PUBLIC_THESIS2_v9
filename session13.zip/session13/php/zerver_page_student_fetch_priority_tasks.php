<?php

include 'zerver_entrance.php';

session_start();

error_reporting(0);

$email = $_SESSION["curr_email_user"];

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT *, created_questions.question_id as questionid FROM ((created_questions LEFT JOIN classrooms ON created_questions.classroom_id = classrooms.room_id) LEFT JOIN teacher_student_connection ON classrooms.room_name = teacher_student_connection.room_name) LEFT JOIN (SELECT * FROM student_answers WHERE owner_student = '$email') AS T2 ON created_questions.question_id = T2.question_id WHERE student_email = '$email' AND IF (owner_student = student_email, owner_student = student_email, owner_student != student_email OR owner_student IS NULL) = 1 GROUP BY created_questions.question_id;");
    $stmt->execute();
  
    // set the resulting array to associative
    $result = $stmt->FetchAll(PDO::FETCH_ASSOC);

    echo json_encode($result);
  } catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
  }
  $conn = null;
?>