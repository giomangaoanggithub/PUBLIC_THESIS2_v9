<?php

include 'zerver_entrance.php';

session_start();

error_reporting(0);

$email = $_SESSION["curr_email_user"];

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  
    // UPDATE created_questions SET checking_param = '<!@#%GRADES$%^><!@#CORRECT$%^><!@#INCORRECT$%^><!@#ENUMERATE$%^>'
    $sql = "UPDATE student_answers LEFT JOIN teacher_student_connection ON student_answers.owner_student = teacher_student_connection.student_email SET grades = -1, checked = 0, system_confidence = -1;";
  
    // Prepare statement
    $stmt = $conn->prepare($sql);
  
    // execute the query
    $stmt->execute();
  
    // echo a message to say the UPDATE succeeded
    echo 'grades and checking param reset to null';
  } catch(PDOException $e) {
    echo $sql . "<br>" . $e->getMessage();
  }
  
  $conn = null;
?>