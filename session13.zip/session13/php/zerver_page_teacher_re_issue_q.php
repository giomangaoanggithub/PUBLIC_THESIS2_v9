<?php
//CHECKED
include 'zerver_entrance.php';

session_start();

error_reporting(0);

$email = $_SESSION["curr_email_user"];
$question = $_POST["question"];
$hps = $_POST["hps"];
$room = $_POST["room"];
$cheparam = $_POST["cheparam"];
$type = $_POST["type"];
$timestamp=strtotime("+5 Days");
$nowtime =  date('Y-m-d 23:59:00', $timestamp);

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "INSERT INTO created_questions (question, HPS, time_of_issue, due_date, owner_teacher, classroom_id, publish, checking_param, type_question)
  VALUES ('$question', '$hps', current_timestamp(), '$nowtime', '$email', '$room', '1', '$cheparam', '$type')";
  // use exec() because no results are returned
  $conn->exec($sql);
  echo "QUESTION RE-ISSUED";
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;
?>